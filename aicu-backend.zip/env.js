const MongoDB_URL =
  "mongodb+srv://richey24:Rejoice111@cluster0.jjzhz.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

module.exports = MongoDB_URL;
